const PRODUCT_SIZES = ['xs' ,'sm', 'md', 'lg', 'xl', 'xxl', '3xl', '4xl' ,'5xl', "extra large"];

module.exports = { PRODUCT_SIZES }